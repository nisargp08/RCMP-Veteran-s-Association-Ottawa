To Import/Export custom fields and custom post types in wordpress:

1.Download two plugin from the wordpress market by name 'Advanced Custom Fields' and 'Custom Post Type UI'.Once installed you will be able to two new columns added to your admin sidebar
2.Go to 'CPT UI' plugin and click on 'Tools'
3.Inside the 'Import post types' textarea paste the following code : 

	{"events":{"name":"events","label":"Events","singular_label":"event","description":"To store various events occurring throughout the year.","public":"true","publicly_queryable":"true","show_ui":"true","show_in_nav_menus":"true","show_in_rest":"true","rest_base":"","rest_controller_class":"","has_archive":"true","has_archive_string":"","exclude_from_search":"false","capability_type":"post","hierarchical":"false","rewrite":"true","rewrite_slug":"","rewrite_withfront":"true","query_var":"true","query_var_slug":"","menu_position":"","show_in_menu":"true","show_in_menu_string":"","menu_icon":"dashicons-calendar","supports":["title","editor","thumbnail","excerpt","trackbacks","custom-fields","author","page-attributes"],"taxonomies":[],"labels":{"menu_name":"Events","all_items":"","add_new":"","add_new_item":"","edit_item":"","new_item":"","view_item":"","view_items":"","search_items":"","not_found":"","not_found_in_trash":"","parent_item_colon":"","featured_image":"","set_featured_image":"","remove_featured_image":"","use_featured_image":"","archives":"","insert_into_item":"","uploaded_to_this_item":"","filter_items_list":"","items_list_navigation":"","items_list":"","attributes":"","name_admin_bar":""},"custom_supports":""}}

4.After paste click on 'Import' button and now you will be able to see custom post type on your admin panel(In our case 'Events')
5.Go to 'Custom Fields' and select 'Tools'
6.On the right hand side under 'Import Field Groups' upload the .json file and import it.
7.Select 'Tools' on the main admin sidebar and install worpress importer(can be found at the bottom of the list).Once installed run the importer and upload the .xml file and hit 'Upload file and import'.
8. Finally select your username under '1.Import author' and check 'Download and import file attachements'.

After executing the above mentioned steps you will be able to see custom post types and custom field.You can check if the process worked or not by going to main navigation bar of the website and going to 'Introduction' page in the dropdown.